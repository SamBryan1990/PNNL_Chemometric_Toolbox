Ternary plotting for Matlab
===========================

[![DOI](https://zenodo.org/badge/31416657.svg)](https://zenodo.org/badge/latestdoi/31416657)

This code helps you to plot ternary phase data on a ternary phase diagram.

This package is also avialable [from File Exchange](http://www.mathworks.com/matlabcentral/fileexchange/2299-ternplot).

It acts like plot (responds to hold, etc), also includes `ternlabel.m`
to label all three axes. There are also functions to plot three
dimensional plots and contours.
