function rad = deg2rad(deg)
rad = deg / 180 * pi;